import { PageShell } from "@/components/site-shell";

export default function PrivacyPage() {
  return (
    <PageShell>
      <section className="section">
        <div className="section-header">
          <span className="eyebrow">Privacy</span>
          <h1>Privacyverklaring</h1>
          <p>
            Deze pagina beschrijft straks hoe Tandartspraktijk Lissane Schoots
            omgaat met persoonsgegevens en medische gegevens. Voor livegang moet
            deze tekst juridisch en zorgspecifiek worden gecontroleerd.
          </p>
        </div>
      </section>
    </PageShell>
  );
}

import Link from "next/link";
import { Award, HeartHandshake, MessageCircle } from "lucide-react";
import { Checklist, InfoCard, SectionHeader } from "@/components/cards";
import { PageShell } from "@/components/site-shell";

const teamMembers = [
  {
    name: "Lissane Schoots",
    role: "Tandarts en oprichter",
    image:
      "https://images.unsplash.com/photo-1629909613654-28e377c37b09?auto=format&fit=crop&w=900&q=85",
    bio:
      "Lissane opent haar praktijk in Huizen met het idee dat goede tandheelkunde rustig, duidelijk en persoonlijk mag voelen. Ze neemt de tijd om uit te leggen wat ze ziet, welke opties er zijn en welke keuze het beste past bij de patiënt."
  },
  {
    name: "Toekomstige collega",
    role: "Teamuitbreiding",
    image:
      "https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?auto=format&fit=crop&w=900&q=85",
    bio:
      "Hier kan straks een korte introductie komen van een collega, assistent of mondhygiënist. Denk aan specialisme, werkwijze en waar patiënten deze persoon voor kunnen ontmoeten."
  }
];

export default function AboutLissanePage() {
  return (
    <PageShell>
      <section className="section">
        <div className="section-header">
          <span className="eyebrow">Meet the team</span>
          <h1>Maak kennis met de praktijk</h1>
          <p>
            Achter de praktijk staat een team dat patiënten op hun gemak wil
            stellen. Op deze pagina krijgen bezoekers een gezicht bij de mensen
            die hen helpen, met per collega een korte persoonlijke introductie.
          </p>
        </div>
        <article className="team-feature">
          <img src={teamMembers[0].image} alt="Portretfoto van Lissane Schoots" />
          <div>
            <span className="eyebrow">{teamMembers[0].role}</span>
            <h2>{teamMembers[0].name}</h2>
            <p>{teamMembers[0].bio}</p>
            <p>
              Haar stijl is toegankelijk en zorgvuldig: eerst begrijpen wat er
              speelt, daarna samen bepalen wat nodig is. Dat maakt de praktijk
              geschikt voor mensen die duidelijke uitleg belangrijk vinden, maar
              ook voor patiënten die tandartsbezoek spannend vinden.
            </p>
            <div className="actions">
              <Link className="button button-primary" href="/afspraak">
                Kennismakingsafspraak
              </Link>
              <Link className="button button-secondary" href="/portal">
                Inloggen portaal
              </Link>
            </div>
          </div>
        </article>
      </section>

      <section className="section">
        <SectionHeader
          eyebrow="Werkwijze"
          title="Eerst begrijpen, dan behandelen"
          intro="Lissane wil dat patiënten weten wat er gebeurt en waarom. Dat maakt zorg rustiger, voorspelbaarder en menselijker."
        />
        <div className="grid-3">
          <InfoCard title="Rust in de stoel">
            <HeartHandshake size={26} />
            <p>Extra aandacht voor patiënten die tandartsbezoek spannend vinden.</p>
          </InfoCard>
          <InfoCard title="Duidelijke uitleg">
            <MessageCircle size={26} />
            <p>Behandelopties worden in gewone taal besproken, inclusief kosten en alternatieven.</p>
          </InfoCard>
          <InfoCard title="Kwaliteit en preventie">
            <Award size={26} />
            <p>De nadruk ligt op gezonde gewoontes, vroeg signaleren en zorgvuldig behandelen.</p>
          </InfoCard>
        </div>
      </section>

      <section className="section band">
        <SectionHeader
          eyebrow="Team"
          title="De mensen achter de praktijk"
          intro="Wanneer er meer collega’s bijkomen, kunnen zij hier eenvoudig worden toegevoegd met foto, functie en korte tekst."
        />
        <div className="grid-2">
          {teamMembers.map((member) => (
            <article className="team-card" key={member.name}>
              <img src={member.image} alt={`Portretfoto van ${member.name}`} />
              <div>
                <span className="eyebrow">{member.role}</span>
                <h3>{member.name}</h3>
                <p>{member.bio}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="section">
        <div className="grid-2">
          <SectionHeader
            eyebrow="Voor wie"
            title="Een praktijk voor Huizen en omgeving"
            intro="Geschikt voor volwassenen, gezinnen en patiënten die een vaste tandarts zoeken met een persoonlijke benadering."
          />
          <InfoCard title="Wat je mag verwachten">
            <Checklist
              items={[
                "Een warme ontvangst en duidelijke planning",
                "Preventieadvies dat past bij je dagelijkse routine",
                "Transparantie over behandelingen en kosten",
                "Een veilig portaal voor afspraken, dossier en facturen"
              ]}
            />
          </InfoCard>
        </div>
      </section>
    </PageShell>
  );
}

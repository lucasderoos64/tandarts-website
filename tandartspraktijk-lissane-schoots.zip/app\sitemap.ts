import type { MetadataRoute } from "next";

const baseUrl = "https://praktijklissane.nl";

export default function sitemap(): MetadataRoute.Sitemap {
  return ["", "/afspraak", "/inschrijven", "/spoed", "/portal", "/admin"].map(
    (path) => ({
      url: `${baseUrl}${path}`,
      lastModified: new Date(),
      changeFrequency: path === "" ? "weekly" : "monthly",
      priority: path === "" ? 1 : 0.7
    })
  );
}

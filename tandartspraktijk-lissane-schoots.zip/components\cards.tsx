import { CheckCircle2 } from "lucide-react";

export function SectionHeader({
  eyebrow,
  title,
  intro
}: {
  eyebrow: string;
  title: string;
  intro: string;
}) {
  return (
    <div className="section-header">
      <span className="eyebrow">{eyebrow}</span>
      <h2>{title}</h2>
      <p>{intro}</p>
    </div>
  );
}

export function InfoCard({
  title,
  children
}: {
  title: string;
  children: React.ReactNode;
}) {
  return (
    <article className="info-card">
      <h3>{title}</h3>
      {children}
    </article>
  );
}

export function Checklist({ items }: { items: string[] }) {
  return (
    <ul className="checklist">
      {items.map((item) => (
        <li key={item}>
          <CheckCircle2 size={18} />
          {item}
        </li>
      ))}
    </ul>
  );
}

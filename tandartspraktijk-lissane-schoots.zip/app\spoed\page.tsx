import { PhoneCall } from "lucide-react";
import { InfoCard } from "@/components/cards";
import { PageShell } from "@/components/site-shell";
import { practice } from "@/lib/demo-data";

export default function EmergencyPage() {
  return (
    <PageShell>
      <section className="section">
        <div className="section-header">
          <span className="eyebrow">Spoed</span>
          <h1>Acute tandheelkundige klacht</h1>
          <p>
            Bij hevige pijn, zwelling, nabloeding of trauma neemt de patiënt
            telefonisch contact op. Buiten openingstijden verwijst deze pagina
            naar de regionale spoeddienst.
          </p>
        </div>
        <div className="grid-2">
          <InfoCard title="Tijdens openingstijden">
            <PhoneCall size={26} />
            <p>Bel direct {practice.phone}. Online boeken is niet bedoeld voor acute spoed.</p>
          </InfoCard>
          <InfoCard title="Buiten openingstijden">
            <p>
              Toon hier de aangesloten spoeddienst zodra Lissane die heeft
              gekozen. Dit voorkomt onduidelijkheid bij pijnklachten.
            </p>
          </InfoCard>
        </div>
      </section>
    </PageShell>
  );
}

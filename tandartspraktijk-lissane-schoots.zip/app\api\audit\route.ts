import { NextResponse } from "next/server";
import { z } from "zod";
import { demoSession } from "@/lib/security";

const auditSchema = z.object({
  patientId: z.string().optional(),
  action: z.enum(["VIEW", "CREATE", "UPDATE", "DELETE", "DOWNLOAD", "LOGIN", "MFA_VERIFY"]),
  resource: z.string().min(2),
  resourceId: z.string().optional(),
  metadata: z.record(z.unknown()).optional()
});

export async function POST(request: Request) {
  const session = demoSession("DENTIST");
  const parsed = auditSchema.safeParse(await request.json());

  if (!parsed.success) {
    return NextResponse.json({ error: "Ongeldige auditregel" }, { status: 400 });
  }

  return NextResponse.json({
    stored: true,
    log: {
      actorUserId: session.id,
      ...parsed.data,
      createdAt: new Date().toISOString()
    }
  });
}

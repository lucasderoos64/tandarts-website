import { NextResponse } from "next/server";
import { canAccessPatient, demoSession } from "@/lib/security";

export async function GET(
  _request: Request,
  { params }: { params: { documentId: string } }
) {
  const session = demoSession("PATIENT");
  const document = {
    id: params.documentId,
    patientId: "pat_demo",
    privateObjectKey: `patients/pat_demo/${params.documentId}.pdf`
  };

  if (!canAccessPatient(session, document.patientId)) {
    return NextResponse.json({ error: "Geen toegang tot dit document" }, { status: 403 });
  }

  return NextResponse.json({
    signedUrl: `/private-download/${document.privateObjectKey}`,
    expiresInSeconds: 300,
    audit: {
      actorUserId: session.id,
      patientId: document.patientId,
      action: "DOWNLOAD",
      resource: "Document",
      resourceId: document.id
    }
  });
}

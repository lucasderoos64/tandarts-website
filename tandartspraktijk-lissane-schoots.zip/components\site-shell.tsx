import Link from "next/link";
import { CalendarDays, LogIn, MapPin, Phone, ShieldCheck } from "lucide-react";
import { practice } from "@/lib/demo-data";

const navItems = [
  ["Home", "/"],
  ["Meet the team", "/over-lissane"],
  ["Portaal", "/portal"]
];

export function Header() {
  return (
    <header className="site-header">
      <Link className="brand" href="/">
        <span className="brand-mark">LS</span>
        <span>
          <strong>{practice.shortName}</strong>
          <small>Tandarts in Huizen</small>
        </span>
      </Link>
      <nav aria-label="Hoofdnavigatie">
        {navItems.map(([label, href]) => (
          <Link key={href} href={href}>
            {label}
          </Link>
        ))}
      </nav>
      <div className="header-actions">
        <Link className="icon-link" href="/portal" aria-label="Inloggen">
          <LogIn size={18} />
        </Link>
        <Link className="button button-primary" href="/afspraak">
          <CalendarDays size={18} />
          Afspraak maken
        </Link>
      </div>
    </header>
  );
}

export function Footer() {
  return (
    <footer className="footer">
      <div>
        <strong>{practice.name}</strong>
        <p>{practice.address}</p>
        <p>Nieuwe tandartspraktijk in Huizen voor volwassenen en gezinnen.</p>
      </div>
      <div>
        <strong>Contact</strong>
        <p><a href={`tel:${practice.phone.replaceAll(" ", "")}`}>{practice.phone}</a></p>
        <p><a href={`mailto:${practice.email}`}>{practice.email}</a></p>
        <p><Link href="/spoed">Spoed en bereikbaarheid</Link></p>
      </div>
      <div>
        <strong>Openingstijden</strong>
        <p>Ma, di, do: 08:30 - 17:00</p>
        <p>Wo, vr: op afspraak</p>
        <p><a href="/privacy">Privacy</a> · <a href="/cookies">Cookies</a></p>
      </div>
      <div className="security-note">
        <ShieldCheck size={18} />
        Veilig portaal voor bestaande patiënten.
      </div>
    </footer>
  );
}

export function PageShell({ children }: { children: React.ReactNode }) {
  return (
    <>
      <Header />
      <main>{children}</main>
      <Footer />
      <nav className="mobile-actionbar" aria-label="Snelle acties">
        <a href={`tel:${practice.phone.replaceAll(" ", "")}`}>
          <Phone size={18} />
          Bel
        </a>
        <Link href="/afspraak">
          <CalendarDays size={18} />
          Afspraak
        </Link>
        <a href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(practice.address)}`}>
          <MapPin size={18} />
          Route
        </a>
      </nav>
    </>
  );
}

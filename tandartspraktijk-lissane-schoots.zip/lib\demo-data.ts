export const practice = {
  name: "Tandartspraktijk Lissane Schoots",
  shortName: "Lissane Schoots",
  city: "Huizen",
  phone: "035 000 0000",
  email: "info@praktijklissane.nl",
  address: "Oude Raadhuisplein 7, 1271 RH Huizen",
  cancellationHours: 48
};

export const treatments = [
  {
    name: "Periodieke controle",
    duration: 30,
    price: "vanaf EUR 28",
    description: "Rustige controle met ruimte voor vragen, preventieadvies en eventuele vervolgplanning."
  },
  {
    name: "Mondhygiene en preventie",
    duration: 45,
    price: "op indicatie",
    description: "Begeleiding bij tandvleesklachten, reiniging en praktische instructie voor thuis."
  },
  {
    name: "Esthetische tandheelkunde",
    duration: 60,
    price: "offerte",
    description: "Bespreking van wensen rond vorm, kleur en harmonie van het gebit."
  },
  {
    name: "Spoedconsult",
    duration: 20,
    price: "volgens NZa",
    description: "Voor pijnklachten, afgebroken tanden of acute zorgen tijdens openingstijden."
  }
];

export const slots = [
  "Ma 09:00",
  "Ma 10:30",
  "Di 13:00",
  "Wo 08:30",
  "Do 15:30",
  "Vr 11:00"
];

export const patient = {
  name: "Mila van Dijk",
  email: "mila@example.nl",
  phone: "06 1234 5678",
  city: "Huizen",
  mfa: "TOTP actief",
  consents: [
    { subject: "Digitale dossierinzage", granted: true },
    { subject: "Afspraakherinneringen per e-mail", granted: true },
    { subject: "Delen met andere zorgverleners", granted: false }
  ]
};

export const appointments = [
  {
    id: "APT-24031",
    treatment: "Periodieke controle",
    date: "Dinsdag 4 juni 2026",
    time: "10:30",
    status: "Bevestigd",
    canChange: true
  },
  {
    id: "APT-23902",
    treatment: "Mondhygiene en preventie",
    date: "Vrijdag 12 april 2026",
    time: "09:00",
    status: "Afgerond",
    canChange: false
  }
];

export const records = [
  {
    title: "Controle en preventieadvies",
    type: "Behandelnotitie",
    date: "12 april 2026",
    summary: "Geen caries zichtbaar. Tandvlees lokaal gevoelig rond 36/37.",
    result: "Advies: extra aandacht voor interdentaal reinigen, hercontrole over 6 maanden."
  },
  {
    title: "Foto bitewings",
    type: "Resultaat",
    date: "8 januari 2026",
    summary: "Rontgenfoto's beoordeeld en toegevoegd aan dossier.",
    result: "Geen afwijkingen waarvoor directe behandeling nodig is."
  },
  {
    title: "Intake nieuwe patient",
    type: "Consultatie",
    date: "15 december 2025",
    summary: "Medische anamnese doorgenomen, behandelwensen besproken.",
    result: "Preventief behandelplan opgesteld."
  }
];

export const invoices = [
  {
    number: "LS-2026-0042",
    description: "Periodieke controle en preventieadvies",
    amount: "EUR 64,50",
    status: "Open",
    due: "18 juni 2026"
  },
  {
    number: "LS-2026-0018",
    description: "Mondhygiene consult",
    amount: "EUR 89,20",
    status: "Betaald",
    due: "3 mei 2026"
  }
];

export const auditLogs = [
  {
    actor: "Lissane Schoots",
    action: "Dossier bekeken",
    resource: "Patient Mila van Dijk",
    time: "Vandaag 09:14"
  },
  {
    actor: "Assistente",
    action: "Afspraak gewijzigd",
    resource: "APT-24031",
    time: "Gisteren 16:42"
  },
  {
    actor: "Administratie",
    action: "Factuur toegevoegd",
    resource: "LS-2026-0042",
    time: "Gisteren 11:08"
  }
];

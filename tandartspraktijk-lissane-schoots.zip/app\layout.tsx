import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "Tandartspraktijk Lissane Schoots | Tandarts in Huizen",
  description:
    "Nieuwe tandartspraktijk in Huizen met online afspraken, veilig patientenportaal en persoonlijke tandheelkundige zorg.",
  keywords: [
    "tandarts Huizen",
    "tandartspraktijk Huizen",
    "Lissane Schoots",
    "online afspraak tandarts",
    "patientenportaal tandarts"
  ],
  openGraph: {
    title: "Tandartspraktijk Lissane Schoots",
    description: "Rustige, moderne tandheelkundige zorg in Huizen.",
    locale: "nl_NL",
    type: "website"
  }
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="nl">
      <body className={inter.className}>{children}</body>
    </html>
  );
}

export type SessionUser = {
  id: string;
  role: "PATIENT" | "DENTIST" | "ASSISTANT" | "ADMINISTRATION" | "OWNER";
  patientId?: string;
  mfaVerified: boolean;
};

const staffRoles = new Set(["DENTIST", "ASSISTANT", "ADMINISTRATION", "OWNER"]);

export function assertMfa(session: SessionUser) {
  if (!session.mfaVerified) {
    throw new Error("MFA_REQUIRED");
  }
}

export function canAccessPatient(session: SessionUser, patientId: string) {
  if (!session.mfaVerified) return false;
  if (staffRoles.has(session.role)) return true;
  return session.role === "PATIENT" && session.patientId === patientId;
}

export function canEditMedicalRecord(session: SessionUser) {
  return session.mfaVerified && ["DENTIST", "OWNER"].includes(session.role);
}

export function canManageInvoices(session: SessionUser) {
  return session.mfaVerified && ["ADMINISTRATION", "OWNER"].includes(session.role);
}

export function demoSession(role: SessionUser["role"] = "PATIENT"): SessionUser {
  return {
    id: role === "PATIENT" ? "usr_patient_demo" : "usr_staff_demo",
    role,
    patientId: role === "PATIENT" ? "pat_demo" : undefined,
    mfaVerified: true
  };
}

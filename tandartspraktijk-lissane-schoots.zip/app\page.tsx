import Link from "next/link";
import {
  CalendarCheck,
  Clock,
  Euro,
  HeartHandshake,
  MapPin,
  MessageCircle,
  Phone,
  ShieldCheck,
  Star,
  UserPlus,
  Accessibility,
  Moon,
  SmilePlus
} from "lucide-react";
import { Checklist, InfoCard, SectionHeader } from "@/components/cards";
import { PageShell } from "@/components/site-shell";
import { practice, treatments } from "@/lib/demo-data";

const reviewCards = [
  {
    title: "Rustige uitleg",
    text: "Een praktijk waar tijd wordt genomen voor vragen, behandelkeuzes en geruststelling."
  },
  {
    title: "Heldere planning",
    text: "Afspraken, herinneringen en vervolgzorg worden overzichtelijk geregeld."
  },
  {
    title: "Persoonlijke zorg",
    text: "Aandacht voor gezinnen, volwassenen en patiënten die tandartsbezoek spannend vinden."
  }
];

const specialties = [
  "Periodieke controle",
  "Mondhygiëne en preventie",
  "Angstbegeleiding",
  "Tandvleesklachten",
  "Esthetische tandheelkunde",
  "Spoedconsult"
];

const facilities = [
  "Mondhygiënist mogelijk aanwezig",
  "Avondbehandeling mogelijk",
  "Rustige aanpak bij angst",
  "Toegankelijk voor rolstoelen",
  "Online portaal voor afspraken",
  "Heldere uitleg vooraf"
];

export default function HomePage() {
  return (
    <PageShell>
      <section className="hero">
        <div className="hero-copy">
          <span className="eyebrow">Tandarts in Huizen</span>
          <h1>Rustige tandheelkunde, helder uitgelegd.</h1>
          <p>
            Tandartspraktijk Lissane Schoots is een nieuwe praktijk in Huizen
            voor persoonlijke mondzorg, duidelijke behandelkeuzes en digitaal
            gemak voor bestaande patiënten.
          </p>
          <div className="actions">
            <Link className="button button-primary" href="/afspraak">
              <CalendarCheck size={18} />
              Afspraak maken
            </Link>
            <Link className="button button-secondary" href="/inschrijven">
              <UserPlus size={18} />
              Inschrijven
            </Link>
            <Link className="button button-secondary" href="/portal">
              <ShieldCheck size={18} />
              Inloggen portaal
            </Link>
          </div>
        </div>
        <div className="hero-visual" aria-label="Moderne tandartspraktijk">
          <div className="hero-panel">
            <strong>Nieuwe praktijk, vertrouwde aandacht</strong>
            <p>
              Preventie, rust en begrijpelijke uitleg staan centraal vanaf de
              eerste kennismaking.
            </p>
          </div>
        </div>
      </section>

      <section className="trust-strip" aria-label="Praktijkvoordelen">
        <div>
          <strong>Open</strong>
          Neemt nieuwe patiënten aan.
        </div>
        <div>
          <strong>Spoed</strong>
          Bel direct bij acute klachten.
        </div>
        <div>
          <strong>5.0</strong>
          Google-reviewblok voorbereid.
        </div>
        <div>
          <strong>Portaal</strong>
          Afspraken, dossier en facturen overzichtelijk bij elkaar.
        </div>
      </section>

      <section className="section compact-section">
        <div className="quick-actions">
          <Link href="/inschrijven">
            <UserPlus size={22} />
            <span><strong>Nieuwe patiënt?</strong> Schrijf je eenvoudig in</span>
          </Link>
          <a href={`tel:${practice.phone.replaceAll(" ", "")}`}>
            <Phone size={22} />
            <span><strong>Spoed?</strong> Bel {practice.phone}</span>
          </a>
          <Link href="/afspraak">
            <CalendarCheck size={22} />
            <span><strong>Afspraak?</strong> Kies behandeling en dag</span>
          </Link>
        </div>
      </section>

      <section className="section">
        <SectionHeader
          eyebrow="De praktijk"
          title="Voor wie is de praktijk?"
          intro="De praktijk is ontworpen voor patiënten die duidelijke uitleg, preventie en een rustige benadering belangrijk vinden."
        />
        <div className="grid-3">
          <InfoCard title="Gezinnen">
            <HeartHandshake size={26} />
            <p>Vriendelijke zorg voor ouders, kinderen en jongeren met aandacht voor gewenning en preventie.</p>
          </InfoCard>
          <InfoCard title="Volwassenen">
            <MessageCircle size={26} />
            <p>Heldere controles, behandelplannen en advies dat past bij je dagelijkse routine.</p>
          </InfoCard>
          <InfoCard title="Spannende tandartsbezoeken">
            <ShieldCheck size={26} />
            <p>Rustige uitleg, voorspelbare stappen en extra ruimte om vragen te stellen.</p>
          </InfoCard>
        </div>
      </section>

      <section className="section band" id="behandelingen">
        <SectionHeader
          eyebrow="Behandelingen"
          title="Mondzorg met duidelijke opties"
          intro="Van periodieke controle tot preventie en esthetische wensen. Elke afspraak krijgt een heldere duur, uitleg en vervolgstap."
        />
        <div className="grid-3">
          {treatments.map((treatment) => (
            <InfoCard key={treatment.name} title={treatment.name}>
              <p>{treatment.description}</p>
              <p>
                <strong>{treatment.duration} minuten</strong>
              </p>
            </InfoCard>
          ))}
        </div>
      </section>

      <section className="section" id="afspraak">
        <div className="grid-2">
          <div>
            <span className="eyebrow">Afspraak maken</span>
            <h2>Snel plannen, rustig bevestigd</h2>
            <p className="muted">
              Nieuwe patiënten kunnen een voorkeurstijd aanvragen. Bestaande
              patiënten gebruiken straks het portaal voor afspraken, dossier en
              facturen.
            </p>
          </div>
          <InfoCard title="Zo werkt een afspraak">
            <Checklist
              items={[
                "Kies de behandeling of reden van je bezoek",
                "Geef je voorkeursdatum en contactgegevens door",
                "De praktijk bevestigt de afspraak",
                "Je ziet de afspraak daarna terug in het portaal"
              ]}
            />
            <div className="actions" style={{ marginTop: 18 }}>
              <Link className="button button-primary" href="/afspraak">Afspraak aanvragen</Link>
              <Link className="button button-secondary" href="/portal">Bestaande patiënt</Link>
            </div>
          </InfoCard>
        </div>
      </section>

      <section className="section band" id="aanmelden">
        <SectionHeader
          eyebrow="Aanmelden"
          title="In 3 stappen patiënt worden"
          intro="De aanmelding blijft kort en duidelijk. Alleen gegevens die nodig zijn voor contact, planning en veilige portaalactivatie worden gevraagd."
        />
        <div className="grid-3">
          <InfoCard title="1. Aanmelden">
            <p>Vul je contactgegevens en enkele basisgegevens in.</p>
          </InfoCard>
          <InfoCard title="2. Bevestiging">
            <p>De praktijk neemt contact op en plant de eerste afspraak.</p>
          </InfoCard>
          <InfoCard title="3. Portaal">
            <p>Na activatie kun je afspraken, dossierinformatie en facturen bekijken.</p>
          </InfoCard>
        </div>
      </section>

      <section className="section" id="reviews">
        <SectionHeader
          eyebrow="Ervaringen"
          title="Wat patiënten straks mogen verwachten"
          intro="Omdat de praktijk nieuw opent, staan hier voorlopige verwachtingen. Zodra echte reviews beschikbaar zijn, kunnen deze worden vervangen of gekoppeld aan Google Reviews."
        />
        <div className="grid-3">
          {reviewCards.map((review) => (
            <article className="info-card review-card" key={review.title}>
              <p className="stars" aria-label="Vijf sterren">
                <Star size={18} fill="currentColor" /> <Star size={18} fill="currentColor" /> <Star size={18} fill="currentColor" /> <Star size={18} fill="currentColor" /> <Star size={18} fill="currentColor" />
              </p>
              <h3>{review.title}</h3>
              <p>{review.text}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="section band">
        <div className="grid-2">
          <div>
            <SectionHeader
              eyebrow="Specialisaties"
              title="Waar je voor terecht kunt"
              intro="Een helder overzicht helpt patiënten snel herkennen of de praktijk bij hun vraag past."
            />
            <div className="tag-list">
              {specialties.map((specialty) => (
                <span key={specialty}>{specialty}</span>
              ))}
            </div>
          </div>
          <InfoCard title="Faciliteiten">
            <div className="aligned-list">
              {facilities.map((facility, index) => (
                <p key={facility}>
                  {index === 1 ? <Moon size={18} /> : index === 2 ? <SmilePlus size={18} /> : index === 3 ? <Accessibility size={18} /> : <ShieldCheck size={18} />}
                  {facility}
                </p>
              ))}
            </div>
          </InfoCard>
        </div>
      </section>

      <section className="section band" id="locatie">
        <div className="grid-2">
          <div>
            <SectionHeader
              eyebrow="Locatie en bereikbaarheid"
              title="Goed bereikbaar in Huizen"
              intro="Alle praktische informatie staat op één plek: adres, route, openingstijden, parkeren en spoed."
            />
            <Checklist
              items={[
                "Adres en route duidelijk op mobiel",
                "Parkeerinformatie zichtbaar bij de locatie",
                "Telefonisch bereikbaar voor spoedvragen",
                "Portaal voor bestaande patiënten"
              ]}
            />
          </div>
          <InfoCard title="Praktijkinformatie">
            <div className="aligned-list">
              <p>
                <MapPin size={18} />
                <span><strong>{practice.address}</strong></span>
              </p>
              <p>
                <Clock size={18} />
                <span>Ma, di, do: 08:30 - 17:00<br />Wo, vr: op afspraak</span>
              </p>
              <p>
                <Phone size={18} />
                <span>{practice.phone}</span>
              </p>
            </div>
            <div className="map-placeholder">Kaart en route</div>
            <div className="card-actions">
              <a className="button button-primary" href={`tel:${practice.phone.replaceAll(" ", "")}`}>Bel direct</a>
              <a className="button button-secondary" href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(practice.address)}`}>Route</a>
            </div>
          </InfoCard>
        </div>
      </section>

      <section className="section" id="tarieven">
        <div className="grid-2">
          <SectionHeader
            eyebrow="Tarieven en verzekering"
            title="Transparant over kosten"
            intro="De praktijk kan werken met de landelijke tandartstarieven. Bij uitgebreidere behandelingen wordt vooraf besproken wat nodig is en wat de kosten zijn."
          />
          <InfoCard title="Wat patiënten weten vóór behandeling">
            <Euro size={26} />
            <div className="aligned-list">
              {[
                "Kosten worden vooraf begrijpelijk uitgelegd",
                "Bij grotere behandelingen volgt een behandelplan",
                "Facturen zijn later zichtbaar in het portaal",
                "Verzekeringsinformatie kan bij de intake worden besproken"
              ].map((item) => (
                <p key={item}>
                  <ShieldCheck size={18} />
                  <span>{item}</span>
                </p>
              ))}
            </div>
          </InfoCard>
        </div>
      </section>
    </PageShell>
  );
}

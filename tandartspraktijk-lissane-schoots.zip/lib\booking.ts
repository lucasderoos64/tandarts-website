import { practice } from "./demo-data";

export function canPatientChangeAppointment(startsAt: Date, now = new Date()) {
  const limitMs = practice.cancellationHours * 60 * 60 * 1000;
  return startsAt.getTime() - now.getTime() >= limitMs;
}

export function buildAuditMetadata(resource: string, reason: string) {
  return {
    resource,
    reason,
    complianceNote:
      "Patientgegevens alleen tonen na autorisatie en registreren in auditlog."
  };
}

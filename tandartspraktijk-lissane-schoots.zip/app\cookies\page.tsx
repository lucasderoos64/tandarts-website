import { PageShell } from "@/components/site-shell";

export default function CookiesPage() {
  return (
    <PageShell>
      <section className="section">
        <div className="section-header">
          <span className="eyebrow">Cookies</span>
          <h1>Cookiebeleid</h1>
          <p>
            Deze pagina kan straks uitleggen welke noodzakelijke, analytische of
            marketingcookies de website gebruikt. De eerste versie kan starten
            met alleen noodzakelijke cookies.
          </p>
        </div>
      </section>
    </PageShell>
  );
}

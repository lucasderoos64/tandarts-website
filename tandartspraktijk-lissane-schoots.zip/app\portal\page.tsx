import Link from "next/link";
import { ArrowLeft, LockKeyhole, Mail, ShieldCheck } from "lucide-react";
import { PageShell } from "@/components/site-shell";

export default function PortalLoginPage() {
  return (
    <PageShell>
      <section className="section auth-section">
        <div>
          <Link className="back-link" href="/">
            <ArrowLeft size={18} />
            Terug naar home
          </Link>
          <span className="eyebrow">Patiëntenportaal</span>
          <h1>Inloggen voor bestaande patiënten</h1>
          <p>
            Bekijk je afspraken, dossierinformatie, toestemmingen en facturen
            via een beveiligd portaal. Log in met wachtwoord en bevestig daarna
            met een verificatiecode.
          </p>
          <div className="trust-list">
            <p><ShieldCheck size={18} /> MFA-beveiliging voor patiëntgegevens</p>
            <p><LockKeyhole size={18} /> Alleen toegang tot je eigen dossier</p>
            <p><Mail size={18} /> Wachtwoord plus verificatiecode</p>
          </div>
        </div>

        <form className="form-panel login-card">
          <h2>Log in</h2>
          <div className="field">
            <label htmlFor="email">E-mailadres</label>
            <input id="email" name="email" type="email" placeholder="naam@example.nl" />
          </div>
          <div className="field">
            <label htmlFor="password">Wachtwoord</label>
            <input id="password" name="password" type="password" placeholder="Je wachtwoord" />
          </div>
          <div className="field">
            <label htmlFor="code">Verificatiecode</label>
            <input id="code" name="code" inputMode="numeric" placeholder="6-cijferige code" />
          </div>
          <button className="button button-primary" type="button">
            Inloggen
          </button>
          <p className="muted">
            Nog geen account? Schrijf je eerst in als patiënt, dan activeert de
            praktijk je portaaltoegang.
          </p>
          <Link className="button button-secondary" href="/inschrijven">
            Inschrijven
          </Link>
        </form>
      </section>
    </PageShell>
  );
}

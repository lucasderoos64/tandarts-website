import Link from "next/link";
import { ArrowLeft, CalendarDays, UserRound } from "lucide-react";
import { PageShell } from "@/components/site-shell";
import { slots, treatments } from "@/lib/demo-data";

const clinicians = [
  {
    name: "Lissane Schoots",
    role: "Tandarts",
    focus: "Controle, behandelplan en algemene tandheelkunde"
  },
  {
    name: "Mondhygiënist",
    role: "Binnenkort beschikbaar",
    focus: "Preventie, tandvlees en gebitsreiniging"
  }
];

const calendarCells = [
  ["1", ""],
  ["2", "09:00"],
  ["3", "10:30"],
  ["4", "13:00"],
  ["5", "11:00"],
  ["6", ""],
  ["7", ""],
  ["8", "14:00"],
  ["9", "09:30"],
  ["10", "Op aanvraag"],
  ["11", "15:30"],
  ["12", "10:00"],
  ["13", ""],
  ["14", ""],
  ["15", "08:30"],
  ["16", "13:00"],
  ["17", "16:00"],
  ["18", "09:00"],
  ["19", "11:30"],
  ["20", ""],
  ["21", ""]
];

export default function AppointmentPage() {
  return (
    <PageShell>
      <section className="section">
        <Link className="back-link" href="/">
          <ArrowLeft size={18} />
          Terug naar home
        </Link>
        <div className="section-header">
          <span className="eyebrow">Online afspraak maken</span>
          <h1>Kies je afspraak</h1>
          <p>
            Selecteer waarvoor je komt, bij wie je geholpen wilt worden en welke
            daarna een dag in de maandkalender. De praktijk bevestigt de afspraak nog
            persoonlijk.
          </p>
        </div>

        <form className="booking-layout">
          <section className="form-panel">
            <h2>1. Waarvoor kom je?</h2>
            <div className="choice-grid">
              {treatments.map((treatment, index) => (
                <label className="choice-card" key={treatment.name}>
                  <input defaultChecked={index === 0} name="treatment" type="radio" />
                  <span>
                    <strong>{treatment.name}</strong>
                    <small>{treatment.duration} minuten</small>
                    <p>{treatment.description}</p>
                  </span>
                </label>
              ))}
            </div>
          </section>

          <section className="form-panel">
            <h2>2. Kies behandelaar</h2>
            <div className="choice-grid compact">
              {clinicians.map((clinician, index) => (
                <label className="choice-card" key={clinician.name}>
                  <input defaultChecked={index === 0} name="clinician" type="radio" />
                  <span>
                    <UserRound size={22} />
                    <strong>{clinician.name}</strong>
                    <small>{clinician.role}</small>
                    <p>{clinician.focus}</p>
                  </span>
                </label>
              ))}
            </div>
          </section>

          <section className="form-panel">
            <div className="calendar-header">
              <button className="icon-button" type="button" aria-label="Vorige maand">‹</button>
              <div>
                <h2>3. Kies een dag</h2>
                <p>Juni 2026</p>
              </div>
              <button className="icon-button" type="button" aria-label="Volgende maand">›</button>
            </div>
            <div className="month-calendar" aria-label="Kalender juni 2026">
              {["Ma", "Di", "Wo", "Do", "Vr", "Za", "Zo"].map((day) => (
                <span key={day}>{day}</span>
              ))}
              {calendarCells.map(([date, time], index) => (
                <button
                  className={`calendar-cell ${index === 2 ? "selected" : ""} ${[5, 6, 12, 13, 19, 20].includes(index) ? "weekend" : ""}`}
                  key={date}
                  type="button"
                >
                  {date}
                  {time ? <small>{time}</small> : null}
                </button>
              ))}
            </div>
          </section>

          <section className="form-panel">
            <h2>4. Je gegevens</h2>
            <div className="form-grid">
              <div className="field">
                <label htmlFor="name">Naam</label>
                <input id="name" name="name" placeholder="Voor- en achternaam" />
              </div>
              <div className="field">
                <label htmlFor="email">E-mail</label>
                <input id="email" name="email" type="email" placeholder="naam@example.nl" />
              </div>
              <div className="field">
                <label htmlFor="phone">Telefoon</label>
                <input id="phone" name="phone" placeholder="06 1234 5678" />
              </div>
              <div className="field">
                <label htmlFor="patientType">Ik ben</label>
                <select id="patientType" name="patientType">
                  <option>Nieuwe patiënt</option>
                  <option>Bestaande patiënt</option>
                </select>
              </div>
              <div className="field full">
                <label htmlFor="notes">Opmerking of klacht</label>
                <textarea id="notes" name="notes" rows={5} placeholder="Vertel kort waarvoor je komt." />
              </div>
            </div>
            <div className="actions" style={{ marginTop: 18 }}>
              <button className="button button-primary" type="button">
                <CalendarDays size={18} />
                Afspraak aanvragen
              </button>
              <Link className="button button-secondary" href="/portal">
                Bestaande patiënt? Log in
              </Link>
            </div>
          </section>
        </form>
      </section>
    </PageShell>
  );
}

import Link from "next/link";
import { CalendarPlus, ClipboardList, FileText, ShieldAlert } from "lucide-react";
import {
  appointments,
  auditLogs,
  invoices,
  patient,
  practice,
  records,
  treatments
} from "@/lib/demo-data";

export default function AdminPage() {
  return (
    <div className="portal-layout">
      <aside className="sidebar">
        <strong>{practice.shortName}</strong>
        <p>Adminomgeving</p>
        <nav aria-label="Admin navigatie">
          <span className="active">Dashboard</span>
          <span>Agenda</span>
          <span>Patienten</span>
          <span>Dossier</span>
          <span>Facturen</span>
          <span>Auditlog</span>
          <Link href="/">Website</Link>
        </nav>
      </aside>
      <main className="workspace">
        <div className="workspace-header">
          <div>
            <span className="eyebrow">Praktijkteam</span>
            <h1>Beheer voor Lissane en team</h1>
            <p className="muted">
              Rollen: eigenaar/tandarts, assistent en administratie. Medische
              inzage wordt altijd vastgelegd.
            </p>
          </div>
          <div className="actions">
            <button className="button button-secondary" type="button">
              <CalendarPlus size={18} />
              Blokkade toevoegen
            </button>
            <button className="button button-primary" type="button">
              <ClipboardList size={18} />
              Dossieritem
            </button>
          </div>
        </div>

        <section className="grid-3">
          <article className="portal-card">
            <h3>Vandaag</h3>
            <p><strong>8</strong> afspraken gepland</p>
            <p className="muted">1 spoedslot vrij om 15:30</p>
          </article>
          <article className="portal-card">
            <h3>Patienten</h3>
            <p><strong>{patient.name}</strong></p>
            <p className="muted">Laatste dossierinzage vandaag geregistreerd</p>
          </article>
          <article className="portal-card">
            <h3>Open facturen</h3>
            <p><strong>{invoices.filter((invoice) => invoice.status === "Open").length}</strong> open</p>
            <p className="muted">PDF's staan in private opslag</p>
          </article>
        </section>

        <section className="section" style={{ paddingLeft: 0, paddingRight: 0 }}>
          <div className="section-header">
            <span className="eyebrow">Agenda</span>
            <h2>Afspraken en behandelduur</h2>
          </div>
          <article className="portal-card">
            <table className="table">
              <thead>
                <tr>
                  <th>Patient</th>
                  <th>Behandeling</th>
                  <th>Moment</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {appointments.map((appointment) => (
                  <tr key={appointment.id}>
                    <td>{patient.name}</td>
                    <td>{appointment.treatment}</td>
                    <td>{appointment.date} · {appointment.time}</td>
                    <td>
                      <span className={appointment.status === "Bevestigd" ? "status status-good" : "status status-muted"}>
                        {appointment.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </article>
        </section>

        <section className="portal-grid">
          <article className="portal-card">
            <h3>Behandelingen</h3>
            {treatments.map((treatment) => (
              <p key={treatment.name}>
                <strong>{treatment.name}</strong> · {treatment.duration} min
              </p>
            ))}
          </article>
          <article className="portal-card">
            <h3>Dossierbeheer</h3>
            {records.map((record) => (
              <p key={record.title}>
                <FileText size={16} /> {record.title}
              </p>
            ))}
          </article>
        </section>

        <section className="section" style={{ paddingLeft: 0, paddingRight: 0 }}>
          <article className="portal-card">
            <h3>
              <ShieldAlert size={20} /> Auditlog
            </h3>
            <table className="table">
              <thead>
                <tr>
                  <th>Actor</th>
                  <th>Actie</th>
                  <th>Resource</th>
                  <th>Tijd</th>
                </tr>
              </thead>
              <tbody>
                {auditLogs.map((log) => (
                  <tr key={`${log.actor}-${log.time}`}>
                    <td>{log.actor}</td>
                    <td>{log.action}</td>
                    <td>{log.resource}</td>
                    <td>{log.time}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </article>
        </section>
      </main>
    </div>
  );
}

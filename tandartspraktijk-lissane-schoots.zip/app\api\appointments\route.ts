import { NextResponse } from "next/server";
import { z } from "zod";
import { canPatientChangeAppointment } from "@/lib/booking";
import { demoSession } from "@/lib/security";

const appointmentSchema = z.object({
  patientId: z.string().min(3),
  treatmentTypeId: z.string().min(3),
  startsAt: z.string().datetime(),
  notesForPractice: z.string().max(1200).optional()
});

export async function POST(request: Request) {
  const session = demoSession("PATIENT");
  const parsed = appointmentSchema.safeParse(await request.json());

  if (!parsed.success) {
    return NextResponse.json({ error: "Ongeldige afspraakgegevens" }, { status: 400 });
  }

  if (session.patientId !== parsed.data.patientId) {
    return NextResponse.json({ error: "Geen toegang tot deze patient" }, { status: 403 });
  }

  return NextResponse.json({
    status: "REQUESTED",
    message: "Afspraakaanvraag ontvangen",
    audit: {
      actorUserId: session.id,
      patientId: parsed.data.patientId,
      action: "CREATE",
      resource: "Appointment"
    }
  });
}

export async function PATCH(request: Request) {
  const session = demoSession("PATIENT");
  const body = await request.json();
  const startsAt = new Date(String(body.startsAt));

  if (!session.patientId || !canPatientChangeAppointment(startsAt)) {
    return NextResponse.json(
      { error: "Deze afspraak kan niet meer online gewijzigd worden" },
      { status: 409 }
    );
  }

  return NextResponse.json({
    status: "CONFIRMED",
    message: "Wijziging verwerkt",
    cancellationWindowHours: 48
  });
}

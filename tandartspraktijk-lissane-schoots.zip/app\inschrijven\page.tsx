import Link from "next/link";
import { ArrowLeft, ShieldCheck, UserPlus } from "lucide-react";
import { PageShell } from "@/components/site-shell";

export default function RegisterPage() {
  return (
    <PageShell>
      <section className="section auth-section">
        <div>
          <Link className="back-link" href="/">
            <ArrowLeft size={18} />
            Terug naar home
          </Link>
          <span className="eyebrow">Nieuwe patiënt</span>
          <h1>Maak je account aan</h1>
          <p>
            Registreer met je e-mailadres als gebruikersnaam. Daarna kan de
            praktijk je inschrijving bevestigen en portaaltoegang activeren.
          </p>
          <div className="trust-list">
            <p><ShieldCheck size={18} /> E-mailadres wordt je gebruikersnaam</p>
            <p><ShieldCheck size={18} /> Wachtwoord beveiligd opgeslagen in de echte app</p>
            <p><ShieldCheck size={18} /> Menselijke check tegen spamregistraties</p>
          </div>
        </div>

        <form className="form-panel login-card">
          <h2>Registreren</h2>
          <div className="field">
            <label htmlFor="email">E-mailadres</label>
            <input id="email" name="email" type="email" placeholder="naam@example.nl" />
          </div>
          <div className="field">
            <label htmlFor="password">Wachtwoord</label>
            <input id="password" name="password" type="password" placeholder="Minimaal 8 tekens" />
          </div>
          <div className="field">
            <label htmlFor="repeatPassword">Herhaal wachtwoord</label>
            <input id="repeatPassword" name="repeatPassword" type="password" placeholder="Herhaal je wachtwoord" />
          </div>
          <label className="human-check">
            <input type="checkbox" />
            Ik ben een mens
          </label>
          <button className="button button-primary" type="button">
            <UserPlus size={18} />
            Account aanmaken
          </button>
          <p className="muted">Heb je al een account? Log dan in via het portaal.</p>
          <Link className="button button-secondary" href="/portal">
            Inloggen portaal
          </Link>
        </form>
      </section>
    </PageShell>
  );
}
